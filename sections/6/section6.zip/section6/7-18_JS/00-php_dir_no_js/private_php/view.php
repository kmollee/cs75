<html>
  <head>
    
    <title><?php echo $data['Title'] ?></title>
    <meta charset='utf-8'>
    <script src="<?php echo JS_URL_DIR ?>/main.js"></script>   

  </head>
  <body>
    <h1><?php echo $data['title'] ?></h1>
    <?php echo $data['directory_html']; ?>
  </body>
</html>
