        <div class='navbar navbar-fixed-top'>
          <div class='navbar-inner'>
            <div class='container'>
              <a class='brand' href='#'>
              <?php echo $data['blog_title'] ?>
              </a>
              <div class='pull-right'>
                <a class='brand'><?php 
                  echo $data['blog_subtitle'] 
                ?></a>
              </div><!--pull-right-->
            </div><!--container-->
          </div><!--navbar-inner-->
        </div><!--navbar-->
