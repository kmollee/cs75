    <meta charset='utf-8'>
    <link rel='stylesheet' type='text/css'
      href='../bootstrap/css/bootstrap.min.css'/>
    <style type='text/css'>
    body {
        padding-top: 60px;
        padding-bottom: 40px;
    }
    h2 {
        font-style:italic;
    }
    </style>
    <link rel='stylesheet' type='text/css' 
      href='../bootstrap/css/bootstrap-responsive.css'/>
