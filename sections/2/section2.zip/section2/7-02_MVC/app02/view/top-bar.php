        <div class='navbar navbar-fixed-top'>
          <div class='navbar-inner'>
            <div class='container'>
              <a class='brand' href='#'>
        MVC Blog
              </a>
              <div class='pull-right'>
                <a class='brand'>Exploring 
                  <abbr title='Model, View, Controller'>
                    MVC
                  </abbr> since 2002
                </a>
              </div><!--pull-right-->
            </div><!--container-->
          </div><!--navbar-inner-->
        </div><!--navbar-->
