<?php
echo 
"
<!DOCTYPE html>
<html lang='en'>
  <head>
";
include('header-content.php');
echo 
"
  </head>
  <body>
";
include('top-bar.php');
include('content.php');
echo 
"
  </body>
</html>
";
