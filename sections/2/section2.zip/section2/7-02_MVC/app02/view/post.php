
            <div class='well'>
<?php 
/*
Data is available here in the $post variable
*/
echo $post->title;
?> 
            </div><!--well-->
