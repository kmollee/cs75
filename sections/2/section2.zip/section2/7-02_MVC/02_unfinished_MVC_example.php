<?php
define('APP_FOLDER','app02/');
define('M', APP_FOLDER . 'model/');
define('V', APP_FOLDER . 'view/');
define('C', APP_FOLDER . 'controller/');

// now start the controller
require(C . "controller.php");
