<!DOCTYPE html>
    <head><title></title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
    <script src="masonry.js"></script>
    <script>
        
    var image = "";
    
    $(window).load(function () {
    $(function(){
      $('#container').masonry({
        // options
        itemSelector : '.item',
        columnWidth : 240,
        isAnimated: true,
        isFitWidth: true
      });
    });
    
    getRandomImage();
    });
    
    
    function appendImage() {
        getRandomImage();
      $('#container').append("<div class='item'><img src='" + image + "' alt='' /></div>");
      $('#container').masonry('reload');
    } 
    
    function prependImage() {
        getRandomImage();
      $('#container').prepend("<div class='item'><img src='" + image + "' alt='' /></div>")
      $('#container').masonry('reload');
    } 
    
    function getRandomImage() {
        var images_array = new Array();
        images_array[0] = "http://nssdc.gsfc.nasa.gov/imgcat/hires/vg1_p21259.gif";
        images_array[1] = "http://upload.wikimedia.org/wikipedia/commons/0/09/Saturn-cassini-March-27-2004.jpg";
        images_array[2] = "http://upload.wikimedia.org/wikipedia/commons/thumb/3/30/Mercury_in_color_-_Prockter07_centered.jpg/240px-Mercury_in_color_-_Prockter07_centered.jpg";
        
        image_number = Math.floor(Math.random() * 3);
        image = images_array[image_number];
    
    } 
        
    </script>
    <style type="text/css">
    .item {float:left;width:220px;margin:10px;}
    img {width:220px;}
    </style>
    </head>
    
    <body>
        <div id="controls">
            <a href="#" onclick="appendImage()">APPEND IMAGE</a>
            <a href="#" onclick="prependImage()">PREPEND IMAGE</a>    
        </div>
        <div id="container">
            <div class="item"><img src="http://en.es-static.us/upl/2011/02/solar_system.jpg" alt="" /></div>
            <div class="item"><img src="http://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Jupiter_gany.jpg/220px-Jupiter_gany.jpg" alt="" /></div>
            <div class="item"><img src="http://en.es-static.us/upl/2011/02/solar_system.jpg" alt="" /></div>
            <div class="item"><img src="http://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Jupiter_gany.jpg/220px-Jupiter_gany.jpg" alt="" /></div>
            <div class="item"><img src="http://en.es-static.us/upl/2011/02/solar_system.jpg" alt="" /></div>
            <div class="item"><img src="http://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Jupiter_gany.jpg/220px-Jupiter_gany.jpg" alt="" /></div>
            <div class="item"><img src="http://en.es-static.us/upl/2011/02/solar_system.jpg" alt="" /></div>
            <div class="item"><img src="http://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Jupiter_gany.jpg/220px-Jupiter_gany.jpg" alt="" /></div>
        </div>
    </body>
</html>
